package com.fatec.labivbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LabivbackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
