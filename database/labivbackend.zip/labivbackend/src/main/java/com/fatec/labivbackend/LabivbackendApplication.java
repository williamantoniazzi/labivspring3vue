package com.fatec.labivbackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LabivbackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(LabivbackendApplication.class, args);
	}

}
